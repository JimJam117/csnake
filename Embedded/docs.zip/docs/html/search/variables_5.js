var searchData=
[
  ['membranenum_0',['membraneNum',['../main_8c.html#a5fd7cbedad4d5fb381472be5a22c610c',1,'main.c']]]
];
