var searchData=
[
  ['main_0',['main',['../main_8c.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main.c']]],
  ['main_2ec_1',['main.c',['../main_8c.html',1,'']]],
  ['membranenum_2',['membraneNum',['../main_8c.html#a5fd7cbedad4d5fb381472be5a22c610c',1,'main.c']]],
  ['movement_3',['movement',['../main_8c.html#afe14ecbeb5a1b58c61be23a557fabe88',1,'main.c']]]
];
