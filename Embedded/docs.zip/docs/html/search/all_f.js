var searchData=
[
  ['updateplayer_0',['updatePlayer',['../main_8c.html#a9e55dbb80a29480351146c3dbb1fa6b2',1,'main.c']]]
];
