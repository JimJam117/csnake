var searchData=
[
  ['score_0',['score',['../main_8c.html#aef160b7437d94056f1dc59646cd5b87d',1,'main.c']]],
  ['scorecalc_1',['scoreCalc',['../main_8c.html#a76e9103f8265bd57f023387d96cea6ff',1,'main.c']]],
  ['scorestr_2',['scoreStr',['../main_8c.html#ac31b86b5e2d7f916c96c62e112442d56',1,'main.c']]],
  ['setgameover_3',['setGameOver',['../main_8c.html#a49e1d0816e9e0cabfb855147f399f5b5',1,'main.c']]],
  ['systemclock_5fconfig_4',['SystemClock_Config',['../main_8c.html#a70af21c671abfcc773614a9a4f63d920',1,'main.c']]]
];
