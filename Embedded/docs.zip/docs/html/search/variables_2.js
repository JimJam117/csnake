var searchData=
[
  ['gamearea_0',['gameArea',['../main_8c.html#a92f71d30610a84990fa0110925ab6b17',1,'main.c']]],
  ['gameisrunning_1',['gameIsRunning',['../main_8c.html#a3355dd32a1037b568bc46eca62bcfa5b',1,'main.c']]],
  ['gamespeed_2',['gameSpeed',['../main_8c.html#a64dd4fbaafe16e055e36cc3a0b3da6ba',1,'main.c']]]
];
