var searchData=
[
  ['gamearea_0',['gameArea',['../main_8c.html#a92f71d30610a84990fa0110925ab6b17',1,'main.c']]],
  ['gameisrunning_1',['gameIsRunning',['../main_8c.html#a3355dd32a1037b568bc46eca62bcfa5b',1,'main.c']]],
  ['gameover_2',['gameOver',['../main_8c.html#a026d019671eda0cfe729200fc24d23ba',1,'main.c']]],
  ['gamespeed_3',['gameSpeed',['../main_8c.html#a64dd4fbaafe16e055e36cc3a0b3da6ba',1,'main.c']]],
  ['generatefood_4',['generateFood',['../main_8c.html#aa6fed1924bd85ce47b19d1248a37a70f',1,'main.c']]]
];
