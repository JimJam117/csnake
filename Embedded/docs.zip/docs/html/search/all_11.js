var searchData=
[
  ['x_0',['x',['../main_8c.html#a6150e0515f7202e2fb518f7206ed97dc',1,'main.c']]]
];
