var searchData=
[
  ['changedirection_0',['changeDirection',['../main_8c.html#a9d6b655a52683afe2f4cb87e3f64bc2e',1,'main.c']]],
  ['checkfood_1',['checkFood',['../main_8c.html#abb91124abfa3ea1baf84a06b1d66c4ed',1,'main.c']]],
  ['clearscreen_2',['clearScreen',['../main_8c.html#a9d7e8af417b6d543da691e9c0e2f6f9f',1,'main.c']]]
];
