var searchData=
[
  ['direction_0',['direction',['../main_8c.html#a886d551d5381dc3e53f17825ffc51641',1,'main.c']]]
];
