var searchData=
[
  ['gameover_0',['gameOver',['../main_8c.html#a026d019671eda0cfe729200fc24d23ba',1,'main.c']]],
  ['generatefood_1',['generateFood',['../main_8c.html#aa6fed1924bd85ce47b19d1248a37a70f',1,'main.c']]]
];
