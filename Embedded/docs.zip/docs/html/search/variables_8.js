var searchData=
[
  ['score_0',['score',['../main_8c.html#aef160b7437d94056f1dc59646cd5b87d',1,'main.c']]],
  ['scorestr_1',['scoreStr',['../main_8c.html#ac31b86b5e2d7f916c96c62e112442d56',1,'main.c']]]
];
