var searchData=
[
  ['scorecalc_0',['scoreCalc',['../main_8c.html#a76e9103f8265bd57f023387d96cea6ff',1,'main.c']]],
  ['setgameover_1',['setGameOver',['../main_8c.html#a49e1d0816e9e0cabfb855147f399f5b5',1,'main.c']]],
  ['systemclock_5fconfig_2',['SystemClock_Config',['../main_8c.html#a70af21c671abfcc773614a9a4f63d920',1,'main.c']]]
];
