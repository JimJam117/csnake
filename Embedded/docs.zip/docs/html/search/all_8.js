var searchData=
[
  ['level_0',['level',['../main_8c.html#acf4d33ee4cff36f69b924471174dcb11',1,'main.c']]],
  ['levelcalc_1',['levelCalc',['../main_8c.html#af1a3396a3dfb5e0b340da0b4c4e7cf62',1,'main.c']]]
];
