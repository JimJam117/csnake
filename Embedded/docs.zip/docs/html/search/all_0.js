var searchData=
[
  ['borders_0',['borders',['../main_8c.html#a8c62ff42543b7a912cdfd428760c9066',1,'main.c']]]
];
