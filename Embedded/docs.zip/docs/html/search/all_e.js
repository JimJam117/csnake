var searchData=
[
  ['tail_0',['tail',['../main_8c.html#aff39d864a6594bc5f4a5e365282e00fe',1,'main.c']]]
];
